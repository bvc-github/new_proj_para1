package newUserRegistration;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class billingaddress {

	
	WebDriver driver ;
	
	
	@BeforeMethod
	public void beforemethod() {
		System.setProperty("webdriver.chrome.driver","C:\\software\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.get("http://demowebshop.tricentis.com/login");
		driver.findElement(By.id("Email")).sendKeys("sidwagh11@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("sidwagh");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

		driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
		List<WebElement> element=driver.findElements(By.id("termsofservice"));
		element.get(0).click();
		driver.findElement(By.name("checkout")).click();
		
		Select newaddress=new Select(driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]")));
		newaddress.selectByVisibleText("New Address");
		}
	
	
	@Test
	@Parameters({"company","City","Address1","zipcode","phone"})
	public void paramTest(String company,String City,String Address1 ,String zipcode ,String phone) throws InterruptedException{
		
		driver.findElement(By.id("BillingNewAddress_Company")).sendKeys(company);
		
		Select sCountry=new Select(driver.findElement(By.id("BillingNewAddress_CountryId")));
		sCountry.selectByVisibleText("India");
	    
		Select sState=new Select(driver.findElement(By.id("BillingNewAddress_StateProvinceId")));
		sState.selectByIndex(0);
		
	 	driver.findElement(By.id("BillingNewAddress_City")).sendKeys(City);
	 	
	 	driver.findElement(By.id("BillingNewAddress_Address1")).sendKeys(Address1);
	
	 	driver.findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys(zipcode);
	 
	 	driver.findElement(By.id("BillingNewAddress_PhoneNumber")).sendKeys(phone);
	 	
	 	driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
	 
	 	
	 	Thread.sleep(10000);
	 	
		driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
		List<WebElement> element=driver.findElements(By.id("termsofservice"));
		element.get(0).click();
		driver.findElement(By.name("checkout")).click();
		
		Select newaddress=new Select(driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]")));
		newaddress.selectByVisibleText("New Address");
		
driver.findElement(By.id("BillingNewAddress_Company")).sendKeys(company);
		
		Select s2Country1=new Select(driver.findElement(By.id("BillingNewAddress_CountryId")));
		s2Country1.selectByVisibleText("India");
	    
		Select s2State1=new Select(driver.findElement(By.id("BillingNewAddress_StateProvinceId")));
		s2State1.selectByIndex(0);
		
	 	driver.findElement(By.id("BillingNewAddress_City")).sendKeys(City);
	 	
	 	driver.findElement(By.id("BillingNewAddress_Address1")).sendKeys(Address1);
	 
	
	 	driver.findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys();

	 	driver.findElement(By.id("BillingNewAddress_PhoneNumber")).sendKeys(phone);
	 	
	 	driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
	
	 	String msg=driver.findElement(By.xpath("//span[@class='field-validation-error']")).getText();
		 System.out.println(msg);
	 	


	}
}

