package newUserRegistration;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Registration {

	
	WebDriver driver ;
	
	 
	
    @BeforeMethod
    public void Setup() throws InterruptedException{
   	 System.setProperty("webdriver.chrome.driver","C:\\software\\chromedriver.exe");
		 driver =new ChromeDriver();
		//Maximize browser
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//Open Url
		driver.get("http://demowebshop.tricentis.com/");
		Thread.sleep(1000);
    }
	
	@Test
	@Parameters({"fn","ln","email","password","Cpassword","WrongEmail","Wpassword"})
	public void ParamTest(String firstname,String lastname,String email , String password,String Cpassword,String Wemail,String Wpassword) throws InterruptedException{
	
	driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
	Thread.sleep(2000);
	
     
    
     
     driver.findElement(By.id("gender-male")).click();
     

     driver.findElement(By.name("FirstName")).sendKeys(firstname);
 	Thread.sleep(2000);
 	
	

     driver.findElement(By.name("LastName")).sendKeys(lastname);
	Thread.sleep(2000);
	

	driver.findElement(By.name("Email")).sendKeys(email);
	Thread.sleep(2000);
	

	driver.findElement(By.id("Password")).sendKeys(password);
	Thread.sleep(2000);
	

	driver.findElement(By.id("ConfirmPassword")).sendKeys(Cpassword);
	Thread.sleep(2000);
		
	driver.findElement(By.id("register-button")).click();
	Thread.sleep(2000);
		

	driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
	driver.findElement(By.name("Email")).sendKeys(Wemail);
	driver.findElement(By.id("Password")).sendKeys();
	 String actual_msg=driver.findElement(By.xpath("//span[contains(text(),'Wrong email')]")).getText();
	 System.out.println(actual_msg);

	Thread.sleep(4000);


	driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
	driver.findElement(By.id("Password")).sendKeys(Wpassword);
	driver.findElement(By.id("ConfirmPassword")).sendKeys();
	 String actual_msg1=driver.findElement(By.xpath("//span[contains(text(),'The password should have at least 6 characters.')]")).getText();
	 System.out.println(actual_msg1);

	Thread.sleep(3000);
	}

     
     @AfterMethod 
     public void afterMethod() {
   	  driver.close();
     }
     }